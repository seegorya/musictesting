image map = "map.png"
image menu1:
    "menu1.png"
    xysize (1925, 1080)
image closed = "door3_floor2_closed.png"

screen map_floor1:
    default d1 = "images/door1_floor1.png"
    default d2 = "images/door2_floor1.png"
    default d3 = "images/door3_floor1.png"
    default l = "images/ladder_floor1.png"

    button:
        background "images/door1_floor1.png"
        unhovered SetScreenVariable("d1", "images/door1_floor1.png")
        hovered SetScreenVariable("d1", "images/door1_floor1_e.png")
        action [Jump("room_1")]
        focus_mask True

    button:
        background "images/door2_floor1.png"
        unhovered SetScreenVariable("d1", "images/door2_floor1.png")
        hovered SetScreenVariable("d1", "images/door2_floor1_e.png")
        action [Jump("room_2")]
        focus_mask True

    button:
        background "images/door3_floor1.png"
        unhovered SetScreenVariable("d1", "images/door3_floor1.png")
        hovered SetScreenVariable("d1", "images/door3_floor1_e.png")
        action [Jump("room_3")]
        focus_mask True

    button:
        background "images/ladder_floor1.png"
        unhovered SetScreenVariable("d1", "images/ladder_floor1.png")
        hovered SetScreenVariable("d1", "images/ladder_floor1_e.png")
        action [Jump("floor_2_up")]
        focus_mask True


    add d1
    add d2
    add d3
    add l

screen map_floor2:
    default d1 = "images/door1_floor2.png"
    default d2 = "images/door2_floor2.png"
    default d3 = "images/door3_floor2.png"
    default lu = "images/ladderu_floor2.png"
    default ld = "images/ladderd_floor2.png"

    button:
        background "images/door1_floor2.png"
        unhovered SetScreenVariable("d1", "images/door1_floor2.png")
        hovered SetScreenVariable("d1", "images/door1_floor2_e.png")
        action [Jump("room_1")]
        focus_mask True

    button:
        background "images/door2_floor2.png"
        unhovered SetScreenVariable("d1", "images/door2_floor2.png")
        hovered SetScreenVariable("d1", "images/door2_floor2_e.png")
        action [Jump("room_2")]
        focus_mask True

    button:
        background "images/door3_floor2.png"
        unhovered SetScreenVariable("d1", "images/door3_floor2.png")
        hovered SetScreenVariable("d1", "images/door3_floor2_e.png")
        action [
            SetScreenVariable("d1", "images/door3_floor2_closed.png"),
            Pause(2.0),
            Call("door3_closed"),
            SetScreenVariable("d1", "images/door3_floor2.png"),
        ]
        focus_mask True

    button:
        background "images/ladderu_floor2.png"
        unhovered SetScreenVariable("d1", "images/ladderu_floor2.png")
        hovered SetScreenVariable("d1", "images/ladderu_floor2_e.png")
        action [Jump("floor_3_up")]
        focus_mask True

    button:
        background "images/ladderd_floor2.png"
        unhovered SetScreenVariable("d1", "images/ladderd_floor2.png")
        hovered SetScreenVariable("d1", "images/ladderd_floor2_e.png")
        action [Jump("floor_1_down")]
        focus_mask True


    add d1
    add d2
    add d3
    add lu
    add ld

screen map_floor3:
    default d1 = "images/door1_floor3.png"
    default d2 = "images/door2_floor3.png"
    default l = "images/ladder_floor3.png"

    button:
        background "images/door1_floor3.png"
        unhovered SetScreenVariable("d1", "images/door1_floor3.png")
        hovered SetScreenVariable("d1", "images/door1_floor3_e.png")
        action [Jump("room_1")]
        focus_mask True

    button:
        background "images/door2_floor3.png"
        unhovered SetScreenVariable("d1", "images/door2_floor3.png")
        hovered SetScreenVariable("d1", "images/door2_floor3_e.png")
        action [Jump("room_2")]
        focus_mask True

    button:
        background "images/ladder_floor3.png"
        unhovered SetScreenVariable("d1", "images/ladder_floor3.png")
        hovered SetScreenVariable("d1", "images/ladder_floor3_e.png")
        action [Jump("floor_2_down")]
        focus_mask True


    add d1
    add d2
    add l

screen menu_test:
    default m1 = "images/menu_1.png"
    default m2 = "images/menu_2.png"

    button:
        background "images/menu_1.png"
        unhovered SetScreenVariable("m1", "images/menu_1_u.png")
        hovered SetScreenVariable("m1", "images/menu_1.png")
        action [Jump("menu_test2")]
        focus_mask True

    button:
        background "images/menu_2.png"
        unhovered SetScreenVariable("m2", "images/menu_2_u.png")
        hovered SetScreenVariable("m2", "images/menu_2.png")
        action [Jump("menu_test2")]
        focus_mask True

    add m1
    add m2

