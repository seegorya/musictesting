﻿define img_c_format = '.png'
default lvl = '1'
default lvl_name = ""
 
label start:
    menu:
        "тестировать звук":
            menu:
                "тестинг звука часть 1"
                "версия 2 (основная)":
                    jump mp3
                "версия 4":
                    jump wav
                "версия 5":
                    jump opus
                "назад":
                    jump start
        "линейный звук":
            jump line_sound
        "демо меню":
            jump menu_test
        "демо карты":
            $ lvl_name = "floor_" + lvl
            $ renpy.jump(lvl_name)

        # "тестировать игру":
        #     python:
        #         catch_game = CatchGame()
        #     show screen catch_game
        #     $ renpy.pause()
        #     return
    return

label line_sound:
    play music "chapter1.mp2"
    "это чекпоинт 1. тут должен начаться звук"
    "тут чутка текста и действий для тестов еще"
    menu:
        "можна выбрать любой варик"
        "1":
            jump line_sound2
        "2":
            jump line_sound2

label line_sound2:
    stop music
    "сейчас музыка не играет"
    play music "chapter2.mp3" fadein 1.0
    "а сейчас должна заиграть. это чекпоинт 2"
    play sound "door-opening.mp3"
    "чекпоинт 3 - тут поверх музыки звук хлопка (с небольшой задержкой это ок)"
    "ща вернемся в меню и там будет чекпоинт 4 - музыка должна продолжаться"
    jump start

label mp2:
    play music "chapter1.mp2"
    "возможно, нужно сперва нажать на экран"
    menu:
        "сработало (в главное меню)":
            jump start
        "не сработало (тестирование вар 2)":
            jump mp2_2

label mp2_2:
    "надо еще раз нажать на экран"
    play music "chapter1.mp2"
    menu:
        "вернуться в главное меню":
            jump start

label mp3:
    play music "chapter1.mp3"
    "возможно, нужно сперва нажать на экран"
    menu:
        "сработало (в главное меню)":
            jump start
        "не сработало (тестирование вар 2)":
            jump mp3_2

label mp3_2:
    "надо еще раз нажать на экран"
    play music "chapter1.mp3"
    menu:
        "вернуться в главное меню":
            jump start

label ogg:
    play music "chapter1.ogg"
    "возможно, нужно сперва нажать на экран"
    menu:
        "сработало (в главное меню)":
            jump start
        "не сработало (тестирование вар 2)":
            jump ogg_2

label ogg_2:
    "надо еще раз нажать на экран"
    play music "chapter1.ogg"
    menu:
        "вернуться в главное меню":
            jump start

label wav:
    play music "chapter1.wav"
    "возможно, нужно сперва нажать на экран"
    menu:
        "сработало (в главное меню)":
            jump start
        "не сработало (тестирование вар 2)":
            jump wav_2

label wav_2:
    "надо еще раз нажать на экран"
    play music "chapter1.wav"
    menu:
        "вернуться в главное меню":
            jump start

label opus:
    play music "chapter1.opus"
    "возможно, нужно сперва нажать на экран"
    menu:
        "сработало (в главное меню)":
            jump start
        "не сработало (тестирование вар 2)":
            jump opus_2

label opus_2:
    "надо еще раз нажать на экран"
    play music "chapter1.opus"
    menu:
        "вернуться в главное меню":
            jump start

label room_1:
    "комната 1"
    $ lvl_name = "floor_" + lvl
    $ renpy.jump(lvl_name)

label room_2:
    "комната 2"
    $ lvl_name = "floor_" + lvl
    $ renpy.jump(lvl_name)

label room_3:
    "комната 3"
    $ lvl_name = "floor_" + lvl
    $ renpy.jump(lvl_name)

label floor_1:
    show map:
        yoffset -2160
    call screen map_floor1

label floor_2:
    show map:
        yoffset -1080
    call screen map_floor2

label floor_3:
    show map:
        yoffset 0
    call screen map_floor3

label floor_2_up:
    $ lvl = "2"
    show map:
        yoffset -2160
    "поднимаемся на 2 этаж"
    centered " {nw=0.1}" 
    show map:
        linear 2 yoffset -1080
    $ renpy.pause(2.0, hard=True)
    "мы на 2 этаже"
    call screen map_floor2

label door3_closed:
    show closed
    "закрыто!"
    hide closed
    call screen map_floor2

label floor_3_up:
    $ lvl = "3"
    show map:
        yoffset -1080
    "поднимаемся на 3 этаж"
    centered " {nw=0.1}" 
    show map:
        linear 2 yoffset 0
    $ renpy.pause(2.0, hard=True)
    "мы на 3 этаже"
    call screen map_floor3

label floor_1_down:
    $ lvl = "1"
    show map:
        yoffset -1080
    "спустимся на 1 этаж"
    centered " {nw=0.1}" 
    show map:
        linear 2 yoffset -2160
    $ renpy.pause(2.0, hard=True)
    "мы на 1 этаже"
    call screen map_floor1

label floor_2_down:
    $ lvl = "2"
    show map:
        yoffset 0
    "спустимся на 2 этаж"
    centered " {nw=0.1}" 
    show map:
        linear 2 yoffset -1080
    $ renpy.pause(2.0, hard=True)
    "мы на 2 этаже"
    call screen map_floor2

label menu_test:
    scene menu1
    "короче я предлагаю выводить кнопки выбора игры не в основное меню, то есть не сюда"
    "а по кнопке начать в этом меню а сделать выбор части типа {w}как ща покажу"
    call screen menu_test

label menu_test2:
    "и тут уже выводить конкретную главу игры"
    return
