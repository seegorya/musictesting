init:
    # фон 
    image game_bg = Transform("images/pie_catcher/background[img_c_format]", size=(800, 600))

    # предметы
    image basket_img = Transform("images/pie_catcher/basket[img_c_format]", size=(120, 60))
    image good_item = Transform("images/pie_catcher/good-item[img_c_format]", size=(40, 40))
    image bad_item = Transform("images/pie_catcher/bad-item[img_c_format]", size=(40, 40))
    $ heart = Text("♥", size=40, color="#FF69B4", bold=True)
    image life_item = heart

init python:
    import random
    import pygame 
    
    class CatchGame:
        def __init__(self):
            # игровое поле
            self.game_width = 800
            self.game_height = 600
            
            # генерация корзины
            self.basket_x = 400  
            self.basket_width = 120
            self.basket_height = 60
            self.basket_y = self.game_height - 140  # 600 - 140 от верхнего края
            
            # объекты в игре
            self.items = []
            self.score = 0
            self.lives = 3
            self.max_lives = 3
            self.game_over = False
            self.base_speed = 2
            self.speed_increase = 0.005
            # типы предметов
            self.ITEM_TYPES = {
                "good": {"points": 10, "lives": 0, "weight": 72},
                "bad": {"points": 0, "lives": -1, "weight": 25},
                "life": {"points": 0, "lives": 1, "weight": 3},
            }
            
            # частота появления предметов
            self.item_timer = 0
            self.item_delay = 45

            self.start_delay = 210
            self.first_item_created = False
            
            # клавиши
            self.keys = {
                "left": False,
                "right": False
            }
            
        # рандомайзер предметов
        def get_random_item_type(self):
            total_weight = sum(item["weight"] for item in self.ITEM_TYPES.values())
            r = random.uniform(0, total_weight)
            all_weight = 0
            
            for item_type, data in self.ITEM_TYPES.items():
                all_weight += data["weight"]
                if r <= all_weight:
                    return item_type

        # создание предмета 
        def create_item(self):
            item_type = self.get_random_item_type()
            data = self.ITEM_TYPES[item_type]

            if len(self.items) > 15:
                return
            
            item = {
                "x": random.randint(50, self.game_width - 40),  
                "y": 0,
                "width": 40,
                "height": 40,
                "speed": random.uniform(self.base_speed, self.base_speed + 1),
                "type": item_type,
                "points": data["points"],
                "lives": data["lives"]
            }
            self.items.append(item)
            self.first_item_created = True
        
        def update(self):
            if self.game_over:
                return
            
            # 5 сек перед первым предметом
            if not self.first_item_created:
                self.start_delay -= 1
                if self.start_delay <= 0:
                    self.create_item()  
                return
            
            # движение корзины (ограничиваем в пределах игрового поля)
            if self.keys["left"]:
                self.basket_x = max(self.basket_width//2 + 10, self.basket_x - 8)
            if self.keys["right"]:
                self.basket_x = min(self.game_width - self.basket_width//2 - 10, self.basket_x + 8)
            
            # создание нового предмета
            self.item_timer += 1
            if self.item_timer >= self.item_delay:
                self.create_item()
                self.item_timer = 0
                self.item_delay = max(30, self.item_delay - 0.2)
            
            # обновляем падающие предметы
            to_remove = []
            for item in self.items:
                item["y"] += item["speed"]
                if self.check_collision(item):
                    self.process_catch(item)
                    to_remove.append(item)
                elif item["y"] > self.game_height - 40:
                    to_remove.append(item)
            
            for item in to_remove:
                if item in self.items:
                    self.items.remove(item)
            
            self.base_speed += self.speed_increase
        
        def check_collision(self, item):
            # проверяем столкновение предмета с корзиной
            basket_left = self.basket_x - self.basket_width//2
            basket_right = self.basket_x + self.basket_width//2
            basket_top = self.basket_y  
            
            item_left = item["x"] - item["width"]//2
            item_right = item["x"] + item["width"]//2
            item_bottom = item["y"] + item["height"]
            
            # возвращаем пересечение
            return (item_bottom >= basket_top and
                    item_right > basket_left and
                    item_left < basket_right)
        
        def process_catch(self, item):
            global game_success, ending_robot
            # в зависимости от пойманного предмета
            self.score += item["points"]
            self.lives += item["lives"]
            
            # максимальное количество жизней
            if self.lives > self.max_lives:
                self.lives = self.max_lives
            
            # конец игры
            if self.lives <= 0 or self.score >=200:
                self.game_over = True
                game_success = True if self.score >= 200 else False
                ending_emotion = renpy.random.choice(['happy', 'wink', 'cunning']) if self.score >= 200 else renpy.random.choice(['sad', 'shocked', 'shocked2']) 
                ending_char = renpy.random.choice(['sup1', 'sup2', 'detective'])
                ending_text = "Пироги собраны" if self.score >= 200 else "Поймано мало пирогов"
                ending_robot = [ending_char, ending_emotion, ending_text]

                show_game_end_screen(
                    game_name="catcher",
                    reset_func=reset_catch_game,
                    pass_ending_robot = ending_robot,
                    hide_func=Hide("catch_game"),
                    jump_label='det_scene1_3_after',
                    #end_game_xysize=(900, 940),
                    end_game_xyalign=(0.44, 0.5)
                )
        
        def update_keys(self):
            # управление через pygame
            try:
                keys = pygame.key.get_pressed()
                self.keys["left"] = keys[pygame.K_LEFT] or keys[pygame.K_a]
                self.keys["right"] = keys[pygame.K_RIGHT] or keys[pygame.K_d]
            except:
                pass

    def reset_catch_game():
        global catch_game
        global ending_robot, game_success
        game_success = False
        renpy.hide("catch_game")
        ending_robot = []
        catch_game = CatchGame()
        renpy.show_screen("catch_game")

screen catch_game():
    tag game
    zorder 100
    modal True

    add Solid("#00000080", xsize=1920, ysize=1080)
    
    default game = store.catch_game
    
    vbox:
        xalign 0.5
        yalign 0.75
        
        frame:
            background Solid("#00000000") 
            xsize 820
            ysize 620
            padding (10, 10, 10, 10)
            
            fixed:
                xsize 800
                ysize 600
            
                add "game_bg"
            
                for item in game.items:
                    if item["type"] == "good":
                        add "good_item":
                            pos (int(item["x"] - item["width"]//2), int(item["y"]))
                    elif item["type"] == "bad":
                        add "bad_item":
                            pos (int(item["x"] - item["width"]//2), int(item["y"]))
                    elif item["type"] == "life":
                        add "life_item":
                            pos (int(item["x"] - item["width"]//2), int(item["y"]))
                
                add "basket_img":
                    pos (int(game.basket_x - game.basket_width//2), int(game.game_height - 140))
    
    $ pause_text = "Как играть"
    $ pause_text2 = "Жми на A и D или стрелки ← →, чтобы двигать корзину и собирать пироги. Избегай ножей и лови дополнительные жизни (одновременно доступно не более трёх жизней). Для победы набери {b}200{/b} очков." 

    if not game.game_over:
        if not game.first_item_created:
            frame:
                xpadding 40
                ypadding 30
                align (0.5, 0.3)
                background Solid('#000')

                vbox:
                    xalign 0.5
                    spacing 15
                    yalign 0.5
                    vbox:
                        xalign 0.5
                        text pause_text2 text_align 0.5 size 24 color "#ffffff"
                        xsize 850
                        ypos 80

                        $ seconds_left = (game.start_delay // 60) + 1
                        text "\nДо начала игры: " + str(seconds_left) size 24 color "#ffffff" xalign 0.5 yalign 0.5 bold True 
        else:
            frame:
                align (0.4, 0.11)
                background Solid('#000')
                
                vbox:
                    xalign 0.5
                    spacing 15
                    yalign 0.5
                    text pause_text size 40 color "#FFFFFF" bold True text_align 0.5 ypos 13 xpos 280
                    frame:
                        background Solid("#ffffff00")
                        text pause_text2 size 20 color "#ffffff" xalign 0.5 yalign 0.5
                        xsize 530
                        xpos 20
                        ypos 40

            frame:
                background Solid('#000')       
                yalign 0.015 
                hbox:
                    ypos 970
                    xpos 750 
                    spacing 80
                    text "ЖИЗНИ: [game.lives]" size 28 color "#ffffff" bold True
                    text "ОЧКИ: [game.score]" size 28 color "#FFFFFF" bold True
                
    timer 0.033 repeat True action [
        Function(game.update_keys),
        Function(game.update)
    ]

